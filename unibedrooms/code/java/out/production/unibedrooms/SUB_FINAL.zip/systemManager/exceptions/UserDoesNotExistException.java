package systemManager.exceptions;

public class UserDoesNotExistException extends Exception{
}
