package systemManager.exceptions;

public class UserAlreadyExistsException extends Exception{

}
