package systemManager.exceptions;

public class NoCandidacysForRoomException extends Exception{
}
