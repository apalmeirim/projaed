package systemManager.exceptions;

public class NotAuthorizedOperationException extends Exception{
}
