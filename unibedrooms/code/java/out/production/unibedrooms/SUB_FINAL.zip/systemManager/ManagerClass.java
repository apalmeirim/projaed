package systemManager;


import java.io.Serializable;

public class ManagerClass extends UserClass implements Manager, Serializable {

    public ManagerClass(String login, String name, String university){
        super(login, name, university);
    }






}
