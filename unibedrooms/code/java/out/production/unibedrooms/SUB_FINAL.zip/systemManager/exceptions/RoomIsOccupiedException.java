package systemManager.exceptions;

public class RoomIsOccupiedException extends Exception{
}
