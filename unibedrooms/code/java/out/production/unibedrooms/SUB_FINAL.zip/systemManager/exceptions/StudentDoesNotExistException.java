package systemManager.exceptions;

public class StudentDoesNotExistException extends Exception{
}
