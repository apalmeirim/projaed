package systemManager.exceptions;

public class ActiveCandidacysException extends Exception{
}
