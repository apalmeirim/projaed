package systemManager.exceptions;

public class NoRoomsExistException extends Exception{
}
