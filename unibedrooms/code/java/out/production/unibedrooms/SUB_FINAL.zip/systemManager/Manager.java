package systemManager;

import java.io.Serializable;

/**
 * @author António Palmeirim numero 63667
 * @author Duarte Inácio numero 62397
 *
 * Interface que representa um gerente no sistema.
 *
 */
public interface Manager extends User, Serializable {

}
