package systemManager.exceptions;

public class CandidacyDoesNotExistException extends Exception{

}
