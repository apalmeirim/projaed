package systemManager.exceptions;

public class RoomDoesNotExistException extends Exception{
}
