package systemManager.exceptions;

public class CandidacyAlreadyExistsException extends Exception{
}
