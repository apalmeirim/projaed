package systemManager.exceptions;

public class NoRoomsInLocationException extends Exception{
}
