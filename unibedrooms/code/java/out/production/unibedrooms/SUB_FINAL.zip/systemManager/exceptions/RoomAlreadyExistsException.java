package systemManager.exceptions;

public class RoomAlreadyExistsException extends Exception{
}
